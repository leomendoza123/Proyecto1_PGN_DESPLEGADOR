(function() {
  var ArrTurnos, Bpieza, Max, Npieza, Nueva, Pos, data2, inicio;
  Bpieza = "Abra un archivo!";
  Npieza = "Abra un archivo!";
  Pos = 1;
  Max = 10;
  ArrTurnos = "NULL";
  data2 = "NULL";
  inicio = 0;
  Nueva = (function() {
    function Nueva() {}
    Nueva.prototype.open = function() {
      var data, fp, nsIFilePicker, res, thefile;
      inicio = 1;
      nsIFilePicker = Components.interfaces.nsIFilePicker;
      fp = Components.classes["@mozilla.org/filepicker;1"].createInstance(nsIFilePicker);
      fp.init(window, "Open File", nsIFilePicker.modeOpen);
      fp.appendFilters(nsIFilePicker.filterText | nsIFilePicker.filterAll);
      res = fp.show();
      if (res === nsIFilePicker.returnOK) {
        thefile = fp.file;
        data = this.read(thefile.path);
      }
      return this.proc(data);
    };
    Nueva.prototype.read = function(filename) {
      var file, inputStream, nsIFileInputStream, nsILocalFile, nsIScriptableInputStream, output, sInputStream;
      nsILocalFile = Components.interfaces.nsILocalFile;
      file = Components.classes["@mozilla.org/file/local;1"].createInstance(nsILocalFile);
      file.initWithPath(filename);
      if (file.exists() === false) {
        alert("File does not exist");
      }
      nsIFileInputStream = Components.interfaces.nsIFileInputStream;
      inputStream = Components.classes["@mozilla.org/network/file-input-stream;1"].createInstance(nsIFileInputStream);
      inputStream.init(file, 0x01, 00004, null);
      nsIScriptableInputStream = Components.interfaces.nsIScriptableInputStream;
      sInputStream = Components.classes["@mozilla.org/scriptableinputstream;1"].createInstance(nsIScriptableInputStream);
      sInputStream.init(inputStream);
      output = sInputStream.read(sInputStream.available());
      return output;
    };
    Nueva.prototype.updis = function() {
      var favorite, tree;
      tree = d3.selectAll("#Bpieza").attr("value", Bpieza);
      tree = d3.selectAll("#Npieza").attr("value", Npieza);
      favorite = "Tuerno actual es " + Pos + "!";
      tree = d3.selectAll("#Lturno").attr("value", favorite);
      tree = d3.selectAll("#NB").attr("value", (data2[4].split('"'))[1]);
      return tree = d3.selectAll("#NN").attr("value", (data2[5].split('"'))[1]);
    };
    Nueva.prototype.Bizq = function() {
      if (Pos > 1) {
        if (inicio !== 0) {
          Pos = Pos - 1;
          this.extraer(Pos);
        }
        return this.updis();
      }
    };
    Nueva.prototype.Bder = function() {
      if (Pos < Max) {
        if (inicio !== 0) {
          Pos = Pos + 1;
          this.extraer(Pos);
        }
        return this.updis();
      }
    };
    Nueva.prototype.proc = function(data) {
      var pos;
      data2 = data.split("\n");
      ArrTurnos = data2[11].split(" ");
      Max = (ArrTurnos.length / 2) - 1;
      pos = 0;
      this.extraer(Pos);
      return this.updis();
    };
    Nueva.prototype.extraer = function(Num_turno) {
      var temp1;
      temp1 = (ArrTurnos[(Num_turno * 2) - 2].split("."))[1];
      Bpieza = temp1;
      temp1 = (ArrTurnos[(Num_turno * 2) - 1].split("."))[0];
      Npieza = temp1;
      return this.updis();
    };
    return Nueva;
  })();
  this.nueva = new Nueva;
}).call(this);
